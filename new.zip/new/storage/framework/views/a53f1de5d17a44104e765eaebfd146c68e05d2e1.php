<?php
    use App\Models\User;
    use App\Models\RankNumber;
    use App\Models\BeHistory;
    use App\Models\Limit;

    $ranknumbers = RankNumber::all()->pluck('ranknumber')->toArray();
    $excessAmount = [];

    $limit = Limit::all()->first();
    $limit_big = $limit->big;
    $limit_small = $limit->small;
    $limit_sold_out_big = $limit->sold_out_big;
    $limit_sold_out_small = $limit->sold_out_small;

    $total_big_excess = 0;
    $total_small_excess = 0;

    foreach($ranknumbers as $num)
    {
        $big = BeHistory::where('number', $num)->sum('big');
        $small = BeHistory::where('number', $num)->sum('small');
        $total_customer = BeHistory::where('number', $num)->count();

        if(!$total_customer)
        {
            continue;
        }

        $excess_big = $big - $limit_big;
        $excess_small = $small - $limit_small;

        $excess_big = $excess_big < 0 ? 0 : $excess_big;
        $excess_small = $excess_small < 0 ? 0 : $excess_small;

        if($big > $limit_sold_out_big)
        {
            $excess_big = 0;
        }

        if($small > $limit_sold_out_small)
        {
            $excess_small = 0;
        }

        if ($excess_big || $excess_small) {
            # code...
            $ele = new stdClass();
            $ele->betno = $num;
            $ele->excess_big = $excess_big;
            $ele->excess_small = $excess_small;
            array_push($excessAmount, $ele);

            $total_big_excess += $excess_big;
            $total_small_excess += $excess_small;
        }
    }
?>


<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.navbars.auth.topnav', ['title' => 'Excess Amount'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid py-4">        
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0">
                        <h6>Excess Amount</h6>
                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center justify-content-center mb-0 admin_activities_1">
                                <thead>
                                    <tr>
                                        <th 
                                            class="text-uppercase text-secondary text-md font-weight-bolder text-center opacity-7 ps-2">
                                            Bettting No</th>
                                        <th
                                            class="text-uppercase text-secondary text-md font-weight-bolder text-center opacity-7 ps-2">
                                            Big</th>
                                        <th
                                            class="text-uppercase text-secondary text-md font-weight-bolder text-center opacity-7 ps-2">
                                            Small</th>                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $excessAmount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ele): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-middle text-center">
                                            <p class="font-weight-bold mb-0"> <?php echo e($ele->betno); ?> </p>                
                                        </td>
                                        <td class="align-middle text-center">
                                            <p class="font-weight-bold mb-0"><?php echo e($ele->excess_big); ?></p>
                                        </td>
                                        <td class="text-center align-middle">
                                            <p class="font-weight-bold mb-0"><?php echo e($ele->excess_small); ?></p>
                                        </td>                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-info">
                                        <td class="align-middle text-center">
                                            <p class="font-weight-bold mb-0"> <strong>Total </p>                
                                        </td>
                                        <td class="align-middle text-center">
                                            <p class="font-weight-bold mb-0"><?php echo e($total_big_excess); ?></p>
                                        </td>
                                        <td class="text-center align-middle">
                                            <p class="font-weight-bold mb-0"><?php echo e($total_small_excess); ?></p>
                                        </td>                                        
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>         
        </div>
        <?php echo $__env->make('layouts.footers.auth.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\_My Projects\Admin panel and backend for 4D be\new\resources\views/pages/excessamount.blade.php ENDPATH**/ ?>